"use client";

import { Reveal } from "./reveal";
import { platformIconByName } from "./platform-icons";
import { Mail, Handshake } from "lucide-react";

const socials = [
  { name: "Instagram", icon: "instagram", url: "https://www.instagram.com/hsrmusicid/" },
  { name: "TikTok", icon: "tiktok", url: "https://www.tiktok.com/@hsrmusicid.official" },
  { name: "Facebook", icon: "facebook", url: "https://www.facebook.com/hsrmusicid.official" },
  { name: "YouTube", icon: "youtube", url: "https://www.youtube.com/@HSRmusicID" },
];

export function Contact() {
  return (
    <section id="kontak" className="mx-auto max-w-6xl px-6 py-28">
      <Reveal>
        <div className="mb-10 flex flex-col items-center text-center">
          <span className="chip mb-4">
            <Handshake className="h-3.5 w-3.5" />
            Kontak
          </span>
          <h2 className="font-serif-display text-3xl leading-[1.15] sm:text-4xl">
            <span className="shimmer-text">Terhubung dengan HSRmusicID</span>
          </h2>
        </div>

        <div className="aurora glass-strong grad-border glow-card relative overflow-hidden rounded-3xl px-6 py-16 text-center sm:px-16">
          {/* ambient glow orb */}
          <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-96 -translate-x-1/2 rounded-full bg-[#c98f5a]/15 blur-3xl" />
          <div className="pointer-events-none absolute inset-0 grain opacity-[0.03]" />

          <div className="relative z-10">
            <div className="glass mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl">
              <Handshake className="h-7 w-7 text-[#c98f5a]" />
            </div>
            <h3 className="font-serif-display text-2xl sm:text-3xl">
              <span className="shimmer-text">Mari Berkolaborasi</span>
            </h3>
            <p className="mx-auto mt-4 max-w-xl text-sm text-[#b8a894] sm:text-base">
              Terima kasih telah menjadikan karya kami sebagai soundtrack hidupmu.
              Untuk kolaborasi, booking, atau kerja sama media, hubungi melalui
              kanal resmi berikut.
            </p>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              {socials.map((s) => (
                <a
                  key={s.name}
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="magnetic glass group inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-[#e8b98a] transition-colors hover:bg-[#c98f5a]/15"
                >
                  <span className="text-[#b8a894] transition-colors group-hover:text-[#e8b98a] [&_svg]:h-4 [&_svg]:w-4">
                    {platformIconByName(s.icon)}
                  </span>
                  {s.name}
                </a>
              ))}
            </div>

            <div className="mt-8 flex items-center justify-center gap-2 text-xs text-[#b8a894]">
              <Mail className="h-4 w-4 text-[#c98f5a]" />
              <span>Booking &amp; kolaborasi: hubungi via Instagram resmi</span>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
