"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Disc3, X } from "lucide-react";
import { usePlayer } from "@/lib/player-store";

/**
 * A small floating button that appears when the player bar is hidden but a
 * track has been loaded. Lets the user re-open the player bar to resume
 * playback. Hidden entirely when the player bar is visible or no track has
 * been selected (srcKey === 0).
 */
export function ShowPlayerButton() {
  const { open, srcKey, current, playing, show, hide } = usePlayer();

  const visible = !open && srcKey > 0;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ type: "spring", stiffness: 280, damping: 30 }}
          className="fixed bottom-4 right-4 z-40 flex items-center gap-2 rounded-full glass-strong px-3 py-2 shadow-lg sm:bottom-6 sm:right-6 lg:right-8"
        >
          <button
            onClick={show}
            className="flex items-center gap-2.5"
            aria-label="Tampilkan player"
          >
            <div className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded-full disc-pattern">
              <Disc3
                className={`h-4 w-4 text-[#0f0c08] ${playing ? "animate-spin-slow" : ""}`}
              />
            </div>
            <div className="hidden text-left sm:block">
              <p className="max-w-[120px] truncate text-xs font-semibold text-[#e8b98a]">
                {current.title}
              </p>
              <p className="text-[10px] text-[#8a7a66]">
                {playing ? "Sedang diputar" : "Dijeda"}
              </p>
            </div>
          </button>
          <button
            onClick={hide}
            className="ml-1 flex h-6 w-6 items-center justify-center rounded-full text-[#8a7a66] transition-colors hover:text-[#e8b98a]"
            aria-label="Tutup"
            title="Tutup"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
