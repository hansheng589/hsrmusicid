"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X, Disc3, Play } from "lucide-react";
import { usePlayer } from "@/lib/player-store";
import { songs } from "@/lib/hsr-data";

/**
 * A slide-in queue panel on the right side (Spotify "Next up" style).
 * Lists all songs; the current one is highlighted. Clicking a song plays it.
 */
export function QueuePanel() {
  const { queueOpen, toggleQueue, current, playSong } = usePlayer();
  const currentIdx = songs.findIndex((s) => s.id === current.id);
  const upNext = [
    ...songs.slice(currentIdx + 1),
    ...songs.slice(0, currentIdx),
  ];

  return (
    <AnimatePresence>
      {queueOpen && (
        <motion.aside
          initial={{ x: 320, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 320, opacity: 0 }}
          transition={{ type: "spring", stiffness: 280, damping: 32 }}
          className="fixed right-0 top-0 z-50 hidden h-screen w-80 flex-col border-l border-[rgba(201,143,90,0.15)] bg-[#0d0a07]/97 backdrop-blur-2xl lg:flex"
        >
          <div className="flex items-center justify-between border-b border-[rgba(201,143,90,0.15)] px-5 py-4">
            <div>
              <p className="font-serif-display text-sm font-bold text-[#e8b98a]">
                Antrian
              </p>
              <p className="text-[10px] uppercase tracking-[0.2em] text-[#a06a3b]">
                Next Up
              </p>
            </div>
            <button
              onClick={toggleQueue}
              className="rounded-full p-2 text-[#b8a894] transition-colors hover:text-[#e8b98a]"
              aria-label="Tutup antrian"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-3">
            {/* Now playing */}
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-[#a06a3b]">
              Sedang Diputar
            </p>
            <div className="mb-4 flex items-center gap-3 rounded-xl bg-[#221a10] px-3 py-2.5">
              <div className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded">
                <div className="absolute inset-0 disc-pattern" />
                <Disc3 className="relative h-5 w-5 animate-spin-slow text-[#0f0c08]" />
              </div>
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold text-[#e8b98a]">
                  {current.title}
                </p>
                <p className="truncate text-[10px] text-[#8a7a66]">
                  HSRmusicID
                </p>
              </div>
            </div>

            {/* Up next list */}
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-[#a06a3b]">
              Berikutnya
            </p>
            <ul className="space-y-0.5">
              {upNext.map((song, i) => (
                <li key={song.id}>
                  <button
                    onClick={() => playSong(song.id)}
                    className="group flex w-full items-center gap-3 rounded-lg px-2.5 py-2 text-left transition-colors hover:bg-[#221a10]"
                  >
                    <span className="w-4 shrink-0 text-right font-serif-display text-xs text-[#a06a3b]">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-[#d9cdbd] group-hover:text-[#e8b98a]">
                        {song.title}
                      </p>
                      <p className="truncate text-[10px] text-[#8a7a66]">
                        HSRmusicID
                      </p>
                    </div>
                    <Play className="h-3.5 w-3.5 shrink-0 fill-[#c98f5a] text-[#c98f5a] opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </motion.aside>
      )}
    </AnimatePresence>
  );
}
