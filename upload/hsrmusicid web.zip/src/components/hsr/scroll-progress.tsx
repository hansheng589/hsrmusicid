"use client";

import { motion, useScroll, useSpring } from "framer-motion";

/**
 * A thin gold progress bar fixed at the top of the viewport that fills
 * as the user scrolls. Uses framer-motion's useScroll (passive scroll
 * listener, GPU-accelerated transform) — extremely lightweight.
 */
export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 30,
    restDelta: 0.001,
  });

  return (
    <motion.div
      style={{ scaleX }}
      className="fixed inset-x-0 top-0 z-[60] h-0.5 origin-left bg-gradient-to-r from-[#a06a3b] via-[#e8b98a] to-[#c98f5a] shadow-[0_0_12px_rgba(201,143,90,0.6)]"
      aria-hidden
    />
  );
}
