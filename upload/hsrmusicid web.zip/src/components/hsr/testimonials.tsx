"use client";

import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { testimonials } from "@/lib/hsr-data";
import { Reveal } from "./reveal";

export function Testimonials() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      <Reveal>
        <p className="text-center text-xs font-semibold uppercase tracking-[0.35em] text-[#c98f5a]">
          Apa Kata Mereka
        </p>
        <h2 className="mt-3 text-center font-serif-display text-3xl text-[#e8b98a] sm:text-4xl">
          Suara Para Pendengar
        </h2>
      </Reveal>

      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {testimonials.map((t, i) => (
          <Reveal key={t.id} delay={i * 0.08}>
            <figure className="relative h-full overflow-hidden rounded-2xl border border-[rgba(201,143,90,0.25)] bg-gradient-to-br from-[#1a140d] to-[#141009] p-6">
              <Quote className="absolute -right-2 -top-2 h-14 w-14 text-[#c98f5a]/10" />

              <div className="relative">
                <div className="mb-3 flex gap-0.5">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star
                      key={j}
                      className="h-3.5 w-3.5 fill-[#c98f5a] text-[#c98f5a]"
                    />
                  ))}
                </div>
                <blockquote className="text-sm leading-relaxed text-[#d9cdbd]">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <figcaption className="mt-4 flex items-center gap-3 border-t border-[rgba(201,143,90,0.15)] pt-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[#c98f5a] to-[#a06a3b] font-serif-display text-sm font-bold text-[#120c06]">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#e8b98a]">
                      {t.name}
                    </p>
                    <p className="text-[11px] text-[#b8a894]">{t.role}</p>
                  </div>
                </figcaption>
              </div>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
