import { HsrLogo } from "./hsr-logo";
import { navLinks } from "@/lib/hsr-data";

export function Footer() {
  return (
    <footer className="aurora relative mt-auto border-t border-[rgba(201,143,90,0.12)] bg-[#0a0806]">
      <div className="section-divider absolute inset-x-0 top-0 z-10" />
      <div className="relative z-10 mx-auto max-w-6xl px-6 py-12">
        <div className="flex flex-col items-center gap-6 text-center">
          <a href="#" className="flex items-center gap-2.5">
            <HsrLogo className="h-7 w-7 rounded-md" />
            <span className="font-serif-display text-sm font-bold tracking-wider">
              <span className="text-[#c98f5a]">HSR</span>{" "}
              <span className="text-[#b8a894]">MUSIC</span>
            </span>
          </a>

          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs font-medium text-[#b8a894]">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="transition-colors hover:text-[#e8b98a]"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <p className="text-xs text-[#b8a894]/70">
            Han Studio Records | HSRmusicID © 2026. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
