"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, Send, CheckCircle2, Loader2, Users } from "lucide-react";
import { Reveal } from "./reveal";
import { useToast } from "@/hooks/use-toast";

type Status = "idle" | "loading" | "success";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const { toast } = useToast();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (status === "loading") return;

    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, name }),
      });
      const data = await res.json();

      if (!res.ok || !data.ok) {
        toast({
          title: "Gagal berlangganan",
          description: data.message ?? "Terjadi kesalahan.",
          variant: "destructive",
        });
        setStatus("idle");
        return;
      }

      setStatus("success");
      toast({
        title: "Berhasil bergabung! 🎵",
        description: data.message,
      });
      setEmail("");
      setName("");
      setTimeout(() => setStatus("idle"), 4000);
    } catch {
      toast({
        title: "Gagal berlangganan",
        description: "Periksa koneksi internetmu dan coba lagi.",
        variant: "destructive",
      });
      setStatus("idle");
    }
  };

  return (
    <section className="mx-auto max-w-6xl px-6 py-28">
      <Reveal>
        <div className="aurora glass-strong grad-border glow-card relative overflow-hidden rounded-3xl p-8 sm:p-12">
          {/* ambient glow orbs */}
          <div className="pointer-events-none absolute -left-20 -top-20 h-60 w-60 rounded-full bg-[#c98f5a]/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -right-20 h-60 w-60 rounded-full bg-[#a06a3b]/15 blur-3xl" />
          <div className="pointer-events-none absolute inset-0 grain opacity-[0.03]" />

          <div className="relative z-10 grid items-center gap-8 lg:grid-cols-2">
            {/* copy */}
            <div>
              <span className="chip mb-4">
                <Mail className="h-3.5 w-3.5" />
                Newsletter
              </span>
              <h2 className="font-serif-display text-3xl leading-[1.15] text-[#e8b98a] sm:text-4xl">
                Dapatkan rilisan terbaru{" "}
                <span className="shimmer-text">lebih dulu</span>
              </h2>
              <p className="mt-4 max-w-md text-sm text-[#b8a894]">
                Bergabung dengan ribuan pendengar setia HSRmusicID. Kamu akan
                menerima notifikasi single baru, jadwal konser, dan konten
                eksklusif langsung ke emailmu.
              </p>
              <div className="mt-4 flex items-center gap-2 text-xs text-[#b8a894]">
                <Users className="h-4 w-4 text-[#c98f5a]" />
                <span>Bergabung sebagai pelopor musik ballad Indonesia</span>
              </div>
            </div>

            {/* form */}
            <div className="glass grad-border relative z-10 overflow-hidden rounded-2xl p-6">
              <AnimatePresence mode="wait">
                {status === "success" ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex flex-col items-center justify-center py-8 text-center"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                      className="bg-gold-gradient mb-4 flex h-16 w-16 items-center justify-center rounded-full"
                    >
                      <CheckCircle2 className="h-8 w-8 text-[#120c06]" />
                    </motion.div>
                    <h3 className="font-serif-display text-lg text-[#e8b98a]">
                      Selamat datang!
                    </h3>
                    <p className="mt-1 text-sm text-[#b8a894]">
                      Cek emailmu untuk konfirmasi.
                    </p>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={submit}
                    className="space-y-3"
                  >
                    <div>
                      <label
                        htmlFor="nl-name"
                        className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[#c98f5a]"
                      >
                        Nama
                      </label>
                      <input
                        id="nl-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Nama kamu"
                        className="w-full rounded-xl border border-[rgba(201,143,90,0.3)] bg-[#0a0806] px-4 py-3 text-sm text-[#f2e9df] placeholder:text-[#b8a894]/50 transition-colors focus:border-[#c98f5a] focus:outline-none focus:ring-2 focus:ring-[#c98f5a]/30"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="nl-email"
                        className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-[#c98f5a]"
                      >
                        Email
                      </label>
                      <input
                        id="nl-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="kamu@email.com"
                        className="w-full rounded-xl border border-[rgba(201,143,90,0.3)] bg-[#0a0806] px-4 py-3 text-sm text-[#f2e9df] placeholder:text-[#b8a894]/50 transition-colors focus:border-[#c98f5a] focus:outline-none focus:ring-2 focus:ring-[#c98f5a]/30"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={status === "loading"}
                      className="magnetic bg-gold-gradient mt-1 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold text-[#120c06] shadow-lg shadow-[#c98f5a]/20 disabled:cursor-not-allowed disabled:opacity-70"
                    >
                      {status === "loading" ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Mengirim...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          Berlangganan
                        </>
                      )}
                    </button>
                    <p className="text-center text-[10px] text-[#b8a894]/70">
                      Kami menghargai privasimu. Unsubscribe kapan saja.
                    </p>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
