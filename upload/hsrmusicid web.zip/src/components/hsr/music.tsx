"use client";

import { useState } from "react";
import { Play, Disc3, Youtube, Heart } from "lucide-react";
import { albums, songs, type Song } from "@/lib/hsr-data";
import { usePlayer } from "@/lib/player-store";
import { Reveal } from "./reveal";
import { TiltCard } from "./tilt-card";
import { YoutubeModal } from "./youtube-modal";

export function Music() {
  const [selected, setSelected] = useState<Song | null>(null);
  const playSong = usePlayer((s) => s.playSong);
  const current = usePlayer((s) => s.current);
  const playing = usePlayer((s) => s.playing);

  return (
    <section id="musik" className="cv-auto px-6 py-20 sm:py-24">
      <Reveal>
        <p className="chip mx-auto mb-3 flex w-fit">
          <Disc3 className="h-3.5 w-3.5" />
          Diskografi
        </p>
        <h2 className="text-center font-serif-display text-3xl font-bold text-[#e8b98a] sm:text-4xl">
          <span className="shimmer-text">Album &amp; Karya</span>
        </h2>
      </Reveal>

      {/* Albums — Spotify-style cards with hover play */}
      <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {albums.map((album, i) => (
          <Reveal key={album.id} delay={i * 0.08}>
            <a
              href={album.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group block rounded-2xl glass grad-border glow-card p-4 transition-all"
            >
              <div className="relative mb-4 aspect-square">
                <div className="absolute inset-0 rounded-xl disc-pattern border border-[rgba(201,143,90,0.3)]" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-serif-display text-3xl font-bold text-[#0f0c08]">
                    {album.initials}
                  </span>
                </div>
                {/* hover play button (Spotify-style green circle) */}
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    const firstInAlbum = songs.find((s) => s.album === album.title);
                    if (firstInAlbum) playSong(firstInAlbum.id);
                  }}
                  className="absolute bottom-2 right-2 flex h-11 w-11 translate-y-2 items-center justify-center rounded-full bg-[#c98f5a] text-[#120c06] opacity-0 shadow-lg transition-all duration-300 hover:scale-105 group-hover:translate-y-0 group-hover:opacity-100"
                  aria-label={`Putar ${album.title}`}
                >
                  <Play className="h-5 w-5 fill-current" />
                </button>
              </div>
              <h3 className="truncate font-serif-display text-sm font-bold text-[#e8b98a]">
                {album.title}
              </h3>
              <p className="mt-0.5 truncate text-xs text-[#b8a894]">
                {album.year} · {album.trackCount} tracks
              </p>
            </a>
          </Reveal>
        ))}
      </div>

      {/* Track list — Spotify-style rows */}
      <Reveal>
        <div className="mt-16 flex items-end justify-between gap-4">
          <div>
            <p className="chip mb-2 inline-flex">
              <Play className="h-3.5 w-3.5" />
              Single &amp; Rilisan
            </p>
            <h3 className="font-serif-display text-2xl font-bold text-[#e8b98a] sm:text-3xl">
              Semua Lagu
            </h3>
          </div>
          <p className="hidden text-sm text-[#8a7a66] sm:block">
            {songs.length} lagu
          </p>
        </div>
      </Reveal>

      {/* List header (desktop) */}
      <div className="mt-6 hidden items-center gap-4 border-b border-[rgba(201,143,90,0.15)] px-4 pb-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-[#8a7a66] sm:flex">
        <span className="w-6 text-center">#</span>
        <span className="flex-1">Judul</span>
        <span className="hidden md:block md:w-32">Album</span>
        <span className="w-20 text-right">Aksi</span>
      </div>

      {/* Track rows */}
      <ul className="mt-2 space-y-0.5">
        {songs.map((song, i) => {
          const isCurrent = current.id === song.id;
          const isPlaying = isCurrent && playing;
          return (
            <li key={song.id}>
              <div
                onDoubleClick={() => playSong(song.id)}
                className={`group grid grid-cols-[1.5rem_1fr_auto] items-center gap-4 rounded-lg px-3 py-2 transition-colors hover:bg-[#221a10] sm:px-4 ${
                  isCurrent ? "bg-[#1a140d]" : ""
                }`}
              >
                {/* index / play button */}
                <div className="flex w-6 items-center justify-center">
                  {isCurrent && isPlaying ? (
                    <div className="flex h-3 items-end gap-0.5">
                      <span className="w-0.5 animate-[hsr-eq_1s_ease-in-out_infinite] bg-[#c98f5a]" style={{ height: "100%" }} />
                      <span className="w-0.5 animate-[hsr-eq_1s_ease-in-out_infinite_0.2s] bg-[#c98f5a]" style={{ height: "60%" }} />
                      <span className="w-0.5 animate-[hsr-eq_1s_ease-in-out_infinite_0.4s] bg-[#c98f5a]" style={{ height: "80%" }} />
                    </div>
                  ) : (
                    <>
                      <span className={`text-sm tabular-nums group-hover:hidden ${isCurrent ? "text-[#c98f5a]" : "text-[#8a7a66]"}`}>
                        {i + 1}
                      </span>
                      <button
                        onClick={() => playSong(song.id)}
                        className="hidden text-[#e8b98a] group-hover:block"
                        aria-label={`Putar ${song.title}`}
                      >
                        <Play className="h-4 w-4 fill-current" />
                      </button>
                    </>
                  )}
                </div>

                {/* title + meta */}
                <div className="flex min-w-0 items-center gap-3">
                  <div
                    className={`h-10 w-10 shrink-0 rounded ${
                      isCurrent ? "disc-pattern" : "bg-[#221a10] border border-[rgba(201,143,90,0.15)]"
                    } flex items-center justify-center`}
                  >
                    <Disc3 className={`h-5 w-5 ${isCurrent ? "animate-spin-slow text-[#0f0c08]" : "text-[#a06a3b]"}`} />
                  </div>
                  <div className="min-w-0">
                    <p className={`truncate text-sm font-medium ${isCurrent ? "text-[#e8b98a]" : "text-[#d9cdbd]"}`}>
                      {song.title}
                    </p>
                    <p className="truncate text-xs text-[#8a7a66]">
                      HSRmusicID{song.album ? ` · ${song.album}` : ""}
                    </p>
                  </div>
                </div>

                {/* actions */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setSelected(song)}
                    className="flex h-8 w-8 items-center justify-center rounded-full text-[#8a7a66] transition-colors hover:bg-[#2d2218] hover:text-[#e8b98a]"
                    aria-label={`Tonton MV ${song.title}`}
                    title="Tonton MV"
                  >
                    <Youtube className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => playSong(song.id)}
                    className={`flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-[#2d2218] ${
                      isCurrent ? "text-[#c98f5a]" : "text-[#8a7a66] hover:text-[#e8b98a]"
                    }`}
                    aria-label={`Putar ${song.title}`}
                    title="Putar"
                  >
                    <Disc3 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <YoutubeModal song={selected} onClose={() => setSelected(null)} />

      <style>{`
        @keyframes hsr-eq {
          0%, 100% { height: 30%; }
          50% { height: 100%; }
        }
      `}</style>
    </section>
  );
}
