"use client";

import { motion } from "framer-motion";
import { Play, Headphones, Heart, Disc3 } from "lucide-react";
import { songs, featuredSongId } from "@/lib/hsr-data";
import { usePlayer } from "@/lib/player-store";
import { Reveal } from "./reveal";

/**
 * A "featured / trending" track spotlight that sits between the About
 * and Music sections to highlight the most popular release.
 *
 * Modernized with glassmorphism cards + a bento grid layout.
 */
export function Featured() {
  const song = songs.find((s) => s.id === featuredSongId) ?? songs[0];
  const playSong = usePlayer((s) => s.playSong);
  // build a small "trending" list of top 4 by plays
  const trending = [...songs]
    .sort((a, b) =>
      (b.plays ?? "0").localeCompare(a.plays ?? "0", undefined, { numeric: true }),
    )
    .slice(0, 4);

  return (
    <section className="mx-auto max-w-6xl px-6 py-24">
      {/* Heading */}
      <Reveal>
        <div className="flex flex-col items-center text-center">
          <span className="chip">Lagu Andalan</span>
          <h2 className="mt-5 font-serif-display text-4xl leading-[1.1] sm:text-5xl">
            <span className="shimmer-text">Trending Sekarang</span>
          </h2>
        </div>
      </Reveal>

      {/* Bento grid: large featured card (col-span-2) + trending list */}
      <div className="mt-14 grid gap-6 lg:grid-cols-3">
        {/* Featured track — large glass card */}
        <Reveal className="lg:col-span-2">
          <div className="glass glass-strong grad-border glow-card relative h-full overflow-hidden rounded-3xl p-8 sm:p-10">
            {/* ambient */}
            <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-[#c98f5a]/15 blur-3xl" />
            <div className="pointer-events-none absolute inset-0 grain opacity-[0.03]" />

            <div className="relative flex flex-col items-center gap-8 sm:flex-row sm:items-center">
              {/* big vinyl */}
              <div className="relative h-44 w-44 shrink-0 sm:h-52 sm:w-52">
                <div className="animate-spin-slow disc-pattern absolute inset-0 rounded-full border border-[rgba(201,143,90,0.3)] shadow-[0_10px_40px_rgba(0,0,0,0.6)]" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Disc3 className="h-12 w-12 text-[#c98f5a]" />
                </div>
                <span className="chip absolute -right-2 -top-2 !bg-gradient-to-br !from-[#c98f5a] !to-[#a06a3b] !text-[#120c06] !border-transparent">
                  #1 Trending
                </span>
              </div>

              <div className="min-w-0 flex-1 text-center sm:text-left">
                <h3 className="font-serif-display text-3xl text-[#e8b98a] sm:text-4xl">
                  {song.title}
                </h3>
                <p className="mt-1.5 text-sm text-[#b8a894]">{song.meta}</p>

                <div className="mt-4 flex flex-wrap justify-center gap-4 text-xs text-[#b8a894] sm:justify-start">
                  <span className="inline-flex items-center gap-1.5">
                    <Headphones className="h-4 w-4 text-[#c98f5a]" />
                    {song.plays} plays
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Heart className="h-4 w-4 text-[#c98f5a]" />
                    Trending #1
                  </span>
                </div>

                <button
                  onClick={() => playSong(song.id)}
                  className="magnetic mt-6 inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-3 text-sm font-semibold text-[#120c06] shadow-lg shadow-[#c98f5a]/25"
                >
                  <Play className="h-4 w-4 fill-current" />
                  Putar Sekarang
                </button>
              </div>
            </div>
          </div>
        </Reveal>

        {/* Trending list — glass card */}
        <Reveal delay={0.15}>
          <div className="glass grad-border glow-card flex h-full flex-col rounded-3xl p-6">
            <p className="mb-4 text-xs font-semibold uppercase tracking-[0.25em] text-[#c98f5a]">
              Trending Lainnya
            </p>
            <ul className="space-y-1">
              {trending.map((t, i) => (
                <li key={t.id}>
                  <button
                    onClick={() => playSong(t.id)}
                    className="group flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition-colors hover:bg-[rgba(201,143,90,0.08)]"
                  >
                    <span className="w-5 font-serif-display text-base font-bold">
                      <span className="shimmer-text">{i + 1}</span>
                    </span>
                    <span className="min-w-0 flex-1 truncate text-sm text-[#d9cdbd] transition-colors group-hover:text-[#e8b98a]">
                      {t.title}
                    </span>
                    {t.plays && (
                      <span className="shrink-0 text-[11px] text-[#b8a894]">
                        {t.plays}
                      </span>
                    )}
                    <Play className="h-3.5 w-3.5 shrink-0 fill-[#c98f5a] text-[#c98f5a] opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
