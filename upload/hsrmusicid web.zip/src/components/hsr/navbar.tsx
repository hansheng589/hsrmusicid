"use client";

import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import { HsrLogo } from "./hsr-logo";
import { navLinks } from "@/lib/hsr-data";

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3" : "py-5"
      }`}
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div
          className={`flex items-center justify-between rounded-full px-5 py-2.5 transition-all duration-500 ${
            scrolled
              ? "glass-strong shadow-[0_8px_30px_-10px_rgba(0,0,0,0.6)]"
              : "border border-transparent"
          }`}
        >
          <a href="#" className="flex items-center gap-2.5" aria-label="HSR Music home">
            <HsrLogo className="h-9 w-9 rounded-lg" />
            <span className="font-serif-display text-base font-bold tracking-wider text-[#e8b98a]">
              HSR<span className="text-[#b8a894] font-normal">music</span>
            </span>
          </a>

          {/* Desktop nav */}
          <div className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="group relative rounded-full px-4 py-2 text-sm font-medium text-[#b8a894] transition-colors hover:text-[#e8b98a]"
              >
                {link.label}
                <span className="absolute inset-x-4 -bottom-0.5 h-px w-0 bg-gradient-to-r from-[#c98f5a] to-[#a06a3b] transition-all duration-300 group-hover:w-[calc(100%-2rem)]" />
              </a>
            ))}
            <a
              href="https://open.spotify.com/artist/4YqIicU1fOtoPP67q7KkDA"
              target="_blank"
              rel="noopener noreferrer"
              className="magnetic ml-2 rounded-full bg-gradient-to-br from-[#e8b98a] to-[#a06a3b] px-5 py-2 text-sm font-semibold text-[#120c06] shadow-[0_6px_20px_-6px_rgba(201,143,90,0.5)]"
            >
              Dengarkan
            </a>
          </div>

          {/* Mobile toggle */}
          <button
            className="text-[#e8b98a] md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        <div
          className={`overflow-hidden transition-all duration-300 md:hidden ${
            open ? "mt-2 max-h-96 opacity-100" : "max-h-0 opacity-0"
          }`}
        >
          <div className="glass-strong flex flex-col gap-1 rounded-3xl p-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-2xl px-4 py-3 text-sm font-medium text-[#b8a894] transition-colors hover:bg-[#221a10] hover:text-[#e8b98a]"
              >
                {link.label}
              </a>
            ))}
            <a
              href="https://open.spotify.com/artist/4YqIicU1fOtoPP67q7KkDA"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setOpen(false)}
              className="mt-1 rounded-2xl bg-gradient-to-br from-[#e8b98a] to-[#a06a3b] px-4 py-3 text-center text-sm font-semibold text-[#120c06]"
            >
              Dengarkan di Spotify
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
