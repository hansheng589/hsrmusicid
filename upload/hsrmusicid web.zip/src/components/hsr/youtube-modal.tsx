"use client";

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Play, Youtube, ExternalLink } from "lucide-react";
import type { Song } from "@/lib/hsr-data";

type YoutubeModalProps = {
  song: Song | null;
  onClose: () => void;
};

export function YoutubeModal({ song, onClose }: YoutubeModalProps) {
  // close on Escape. Don't lock body scroll — the modal container itself is
  // scrollable (overflow-y-auto) so locking the body would prevent scrolling
  // on mobile when the modal is taller than the viewport.
  useEffect(() => {
    if (!song) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
    };
  }, [song, onClose]);

  return (
    <AnimatePresence>
      {song && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-start justify-center overflow-y-auto overscroll-contain p-4 sm:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* backdrop — fixed so it always covers the viewport while modal scrolls */}
          <div
            className="fixed inset-0 z-0 bg-black/85 backdrop-blur-md"
            onClick={onClose}
            aria-hidden
          />

          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label={`Music video ${song.title}`}
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 24 }}
            transition={{ type: "spring", stiffness: 280, damping: 28 }}
            className="relative z-10 my-auto w-full max-w-3xl overflow-hidden rounded-3xl border border-[rgba(201,143,90,0.3)] bg-gradient-to-br from-[#1a140d] to-[#0a0806] shadow-2xl"
          >
            {/* glow */}
            <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-96 -translate-x-1/2 rounded-full bg-[#c98f5a]/20 blur-3xl" />

            {/* header */}
            <div className="relative flex items-center justify-between gap-4 border-b border-[rgba(201,143,90,0.2)] p-5">
              <div className="flex min-w-0 items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#0a0806] border border-[rgba(201,143,90,0.3)]">
                  <Youtube className="h-5 w-5 text-[#c98f5a]" />
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-[#c98f5a]">
                    Official Music Video
                  </p>
                  <h3 className="truncate font-serif-display text-lg text-[#e8b98a]">
                    {song.title}
                  </h3>
                </div>
              </div>
              <button
                onClick={onClose}
                className="rounded-full border border-[rgba(201,143,90,0.3)] p-2 text-[#b8a894] transition-colors hover:border-[#c98f5a] hover:text-[#e8b98a]"
                aria-label="Tutup"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* YouTube embed (16:9) */}
            <div className="relative aspect-video w-full bg-black">
              <iframe
                key={song.youtubeId}
                src={`https://www.youtube-nocookie.com/embed/${song.youtubeId}?autoplay=1&rel=0&modestbranding=1`}
                title={`${song.title} — HSRmusicID`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="absolute inset-0 h-full w-full"
                frameBorder="0"
              />
            </div>

            {/* footer */}
            <div className="flex items-center justify-between gap-3 border-t border-[rgba(201,143,90,0.2)] bg-[#0a0806]/50 p-5">
              <p className="truncate text-xs text-[#b8a894]">
                HSRmusicID{song.album ? ` · ${song.album}` : ""}
              </p>
              <a
                href={`https://www.youtube.com/watch?v=${song.youtubeId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-[#c98f5a] to-[#a06a3b] px-5 py-2.5 text-sm font-semibold text-[#120c06] transition-transform hover:-translate-y-0.5"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                Buka di YouTube
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
