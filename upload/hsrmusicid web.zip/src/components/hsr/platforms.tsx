"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { platforms } from "@/lib/hsr-data";
import { platformIconByName } from "./platform-icons";
import { Reveal } from "./reveal";
import { TiltCard } from "./tilt-card";

export function Platforms() {
  return (
    <section id="platform" className="mx-auto max-w-6xl px-6 py-24 cv-auto">
      <Reveal>
        <p className="text-center text-xs font-semibold uppercase tracking-[0.35em] text-[#c98f5a]">
          Streaming
        </p>
        <h2 className="mt-3 text-center font-serif-display text-3xl text-[#e8b98a] sm:text-4xl">
          Dengarkan di Platform Favoritmu
        </h2>
      </Reveal>

      <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {platforms.map((p, i) => (
          <Reveal key={p.name} delay={i * 0.06}>
            <TiltCard max={10} className="h-full">
              <a
                href={p.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative flex h-full flex-col items-center overflow-hidden rounded-2xl border border-[rgba(201,143,90,0.25)] bg-[#1a140d] p-6 text-center hover:border-[#c98f5a] hover:bg-[#221a10]"
              >
                {/* glow accent on hover */}
                <div
                  className="pointer-events-none absolute -top-12 h-24 w-24 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-40"
                  style={{ background: p.accent }}
                />
                <div
                  className="relative mb-3 transition-colors duration-300"
                  style={{ color: "#b8a894" }}
                >
                  <div className="group-hover:text-[#e8b98a] [&_svg]:h-8 [&_svg]:w-8">
                    {platformIconByName(p.icon)}
                  </div>
                </div>
                <b className="font-serif-display text-sm text-[#e8b98a]">{p.name}</b>
                <span className="mt-1 text-xs text-[#b8a894]">{p.handle}</span>
                <ArrowUpRight className="absolute right-4 top-4 h-4 w-4 text-[#c98f5a] opacity-0 transition-opacity group-hover:opacity-100" />
              </a>
            </TiltCard>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
