type LogoProps = {
  className?: string;
  showText?: boolean;
};

/**
 * HSRmusicID logo — a metallic gold "H" with sound-wave bars,
 * rendered as an inline SVG with gradient definitions.
 */
export function HsrLogo({ className, showText = true }: LogoProps) {
  return (
    <svg
      className={className}
      viewBox="0 0 512 512"
      role="img"
      aria-label="HSR Music logo"
    >
      <defs>
        <radialGradient id="hsrMetal" cx="50%" cy="45%" r="75%">
          <stop offset="0%" stopColor="#f0cba2" />
          <stop offset="45%" stopColor="#c98f5a" />
          <stop offset="100%" stopColor="#7a4e26" />
        </radialGradient>
        <linearGradient id="hsrTextGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#eec9a0" />
          <stop offset="55%" stopColor="#c98f5a" />
          <stop offset="100%" stopColor="#a06a3b" />
        </linearGradient>
      </defs>
      <rect width="512" height="512" fill="#0b0805" />
      <text
        x="256"
        y="355"
        textAnchor="middle"
        fontFamily="Georgia, 'Times New Roman', serif"
        fontSize="330"
        fontWeight="700"
        fill="url(#hsrMetal)"
      >
        H
      </text>
      <g stroke="#0b0805" strokeWidth="9" strokeLinecap="round">
        <line x1="132" y1="238" x2="132" y2="262" />
        <line x1="152" y1="218" x2="152" y2="282" />
        <line x1="172" y1="196" x2="172" y2="304" />
        <line x1="192" y1="208" x2="192" y2="292" />
        <line x1="212" y1="224" x2="212" y2="276" />
        <line x1="232" y1="212" x2="232" y2="288" />
        <line x1="252" y1="230" x2="252" y2="270" />
      </g>
      {showText && (
        <text
          x="256"
          y="452"
          textAnchor="middle"
          fontFamily="Georgia, 'Times New Roman', serif"
          fontSize="52"
          fontWeight="600"
          letterSpacing="10"
          fill="url(#hsrTextGrad)"
        >
          HSR MUSIC
        </text>
      )}
    </svg>
  );
}
