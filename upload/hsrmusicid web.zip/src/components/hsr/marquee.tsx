"use client";

import { songs } from "@/lib/hsr-data";

/**
 * An infinite horizontal marquee of song titles for a dynamic,
 * "ticker" feel between sections.
 */
export function Marquee() {
  // duplicate the list so the animation loops seamlessly
  const items = [...songs, ...songs];

  return (
    <div className="relative overflow-hidden border-y border-[rgba(201,143,90,0.2)] bg-[#0a0806] py-5">
      {/* edge fade masks */}
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#0a0806] to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#0a0806] to-transparent" />

      <div className="flex w-max animate-[hsr-marquee_40s_linear_infinite] gap-8 whitespace-nowrap">
        {items.map((song, i) => (
          <span
            key={`${song.id}-${i}`}
            className="inline-flex items-center gap-3 font-serif-display text-sm text-[#b8a894]/60"
          >
            <span className="text-[#c98f5a]">♪</span>
            {song.title}
            {song.collaborator && (
              <span className="text-[10px] text-[#a06a3b]">
                feat. {song.collaborator}
              </span>
            )}
            <span className="ml-2 text-[#c98f5a]/30">·</span>
          </span>
        ))}
      </div>

      <style>{`
        @keyframes hsr-marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
