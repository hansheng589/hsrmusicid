"use client";

import { motion } from "framer-motion";
import { HsrLogo } from "./hsr-logo";
import { stats, genreTags } from "@/lib/hsr-data";
import { Reveal } from "./reveal";

export function About() {
  return (
    <section id="tentang" className="mx-auto max-w-6xl px-6 py-28">
      {/* Heading */}
      <Reveal>
        <div className="flex flex-col items-center text-center">
          <span className="chip">Tentang</span>
          <h2 className="mt-5 font-serif-display text-4xl leading-[1.1] sm:text-5xl">
            <span className="shimmer-text">Suara di Balik HSR</span>
          </h2>
        </div>
      </Reveal>

      {/* Bento grid: logo card | bio card */}
      <div className="mt-14 grid gap-6 lg:grid-cols-[0.9fr_1.4fr]">
        {/* Logo card */}
        <Reveal>
          <div className="glass glass-strong grad-border glow-card flex h-full items-center justify-center rounded-3xl p-8 sm:p-10">
            <HsrLogo className="aspect-square w-full max-w-xs" />
          </div>
        </Reveal>

        {/* Bio card */}
        <Reveal delay={0.15}>
          <div className="glass grad-border glow-card flex h-full flex-col justify-center rounded-3xl p-8 sm:p-10">
            <p className="text-lg leading-relaxed text-[#b8a894]">
              <strong className="text-[#e8b98a]">HSRmusicID</strong> menghadirkan
              karya original dengan fokus pada melodi mendalam dan lirik bermakna
              dalam genre{" "}
              <strong className="text-[#e8b98a]">Indonesian Pop Ballad</strong>{" "}
              serta <strong className="text-[#e8b98a]">Folk-Akustik</strong>. Setiap
              nada dirancang untuk memberikan ketenangan dan ruang emosional bagi
              pendengar.
            </p>
            <p className="mt-5 leading-relaxed text-[#b8a894]">
              Di bawah naungan label{" "}
              <strong className="text-[#e8b98a]">Han Studio Records</strong>,
              HSRmusicID berdedikasi pada produksi audio yang jujur dan berkualitas
              tinggi.
            </p>

            <div className="mt-6 flex flex-wrap gap-2.5">
              {genreTags.map((tag) => (
                <span key={tag} className="chip">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </div>

      {/* Stats: 4-column glass mini-cards */}
      <div className="mt-6 grid grid-cols-2 gap-6 sm:grid-cols-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08 }}
          >
            <div className="glass glow-card grad-border rounded-2xl p-5 text-center">
              <div className="font-serif-display text-3xl font-bold sm:text-4xl">
                <span className="shimmer-text">{stat.value}</span>
              </div>
              <div className="mt-2 text-xs uppercase tracking-wider text-[#b8a894]">
                {stat.label}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
