"use client";

import { usePlayer } from "@/lib/player-store";

/**
 * A wrapper that applies the correct left padding to the main content area
 * based on whether the left sidebar is collapsed (72px) or expanded (288px).
 * Desktop only — on mobile the sidebar overlays so no padding is needed.
 */
export function MainContent({ children }: { children: React.ReactNode }) {
  const collapsed = usePlayer((s) => s.sidebarCollapsed);
  return (
    <div
      className={`flex-1 transition-[padding] duration-300 ease-out ${
        collapsed ? "md:pl-[72px]" : "md:pl-72"
      }`}
    >
      {children}
    </div>
  );
}
