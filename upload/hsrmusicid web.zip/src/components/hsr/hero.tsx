"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { ChevronDown, Sparkles } from "lucide-react";
import { HsrLogo } from "./hsr-logo";
import { TiltCard } from "./tilt-card";

// pre-computed ambient particle positions (deterministic, no SSR mismatch)
const particles = [
  { left: "8%", top: "22%", size: 4, delay: 0, dur: 7 },
  { left: "18%", top: "68%", size: 6, delay: 1.2, dur: 9 },
  { left: "32%", top: "38%", size: 3, delay: 0.6, dur: 8 },
  { left: "72%", top: "28%", size: 5, delay: 0.3, dur: 10 },
  { left: "84%", top: "62%", size: 4, delay: 1.8, dur: 7.5 },
  { left: "62%", top: "78%", size: 3, delay: 0.9, dur: 9.5 },
  { left: "48%", top: "18%", size: 4, delay: 2.1, dur: 8.5 },
  { left: "90%", top: "44%", size: 3, delay: 1.5, dur: 7 },
];

export function Hero() {
  // parallax on scroll: logo drifts up + fades as you scroll past the hero
  const { scrollY } = useScroll();
  const logoY = useTransform(scrollY, [0, 600], [0, -120]);
  const logoScale = useTransform(scrollY, [0, 600], [1, 0.85]);
  const logoOpacity = useTransform(scrollY, [0, 500], [1, 0]);
  const contentY = useTransform(scrollY, [0, 600], [0, -60]);

  return (
    <header className="aurora relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 pb-20 pt-32 text-center">
      {/* base dark bg */}
      <div className="absolute inset-0 bg-[#0a0806]" />

      {/* floating ambient orbs */}
      <div className="pointer-events-none absolute -left-20 top-1/4 h-72 w-72 rounded-full bg-[#c98f5a]/10 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-1/4 h-80 w-80 rounded-full bg-[#a06a3b]/10 blur-3xl" />

      {/* floating gold dust particles */}
      <div className="pointer-events-none absolute inset-0">
        {particles.map((p, i) => (
          <motion.span
            key={i}
            className="absolute rounded-full bg-[#c98f5a]/60"
            style={{
              left: p.left,
              top: p.top,
              width: p.size,
              height: p.size,
              filter: "blur(0.5px)",
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0, 0.8, 0],
            }}
            transition={{
              duration: p.dur,
              delay: p.delay,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center">
        <motion.div
          style={{ y: logoY, scale: logoScale, opacity: logoOpacity }}
          initial={{ opacity: 0, scale: 0.85, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <TiltCard max={12} className="rounded-[1.75rem]">
            <HsrLogo className="animate-float mx-auto mb-9 h-40 w-44 rounded-[1.75rem] border border-[rgba(201,143,90,0.25)] shadow-[0_0_60px_rgba(201,143,90,0.25),0_20px_50px_rgba(0,0,0,0.6)] sm:h-44 sm:w-48" />
          </TiltCard>
        </motion.div>

        <motion.div
          style={{ y: contentY }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div className="chip mb-5">
            <Sparkles className="h-3.5 w-3.5" />
            Han Studio Records
          </div>
          <h1 className="font-serif-display text-5xl font-bold leading-[1.05] sm:text-6xl md:text-7xl lg:text-[5.5rem]">
            <span className="shimmer-text">HSRmusicID</span>
          </h1>

          <p className="mx-auto mt-5 max-w-2xl text-base font-light leading-relaxed text-[#b8a894] sm:text-lg md:text-xl">
            Melodi mendalam, lirik bermakna —{" "}
            <span className="text-[#e8b98a]">Indonesian Pop Ballad</span> &amp;{" "}
            <span className="text-[#e8b98a]">Folk-Akustik</span> dari Han Studio
            Records.
          </p>

          <div className="mt-9 flex flex-wrap justify-center gap-4">
            <a
              href="https://open.spotify.com/artist/4YqIicU1fOtoPP67q7KkDA"
              target="_blank"
              rel="noopener noreferrer"
              className="magnetic group inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-[#e8b98a] via-[#c98f5a] to-[#a06a3b] px-8 py-4 text-sm font-semibold text-[#120c06] shadow-[0_10px_30px_-8px_rgba(201,143,90,0.5)]"
            >
              <span className="text-base transition-transform group-hover:scale-110">♪</span>
              Dengarkan di Spotify
            </a>
            <a
              href="https://www.youtube.com/@HSRmusicID"
              target="_blank"
              rel="noopener noreferrer"
              className="magnetic inline-flex items-center gap-2 rounded-full glass px-8 py-4 text-sm font-semibold text-[#e8b98a] hover:bg-[#c98f5a]/15"
            >
              <span className="text-base">▶</span>
              YouTube Channel
            </a>
          </div>
        </motion.div>
      </div>

      <a
        href="#tentang"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-[#b8a894]/60"
        aria-label="Scroll down"
      >
        <span className="mb-1 block text-[10px] tracking-[0.3em]">SCROLL</span>
        <ChevronDown className="animate-bob mx-auto h-5 w-5" />
      </a>
    </header>
  );
}
