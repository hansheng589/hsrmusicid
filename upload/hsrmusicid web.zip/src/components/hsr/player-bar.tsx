"use client";

import { useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Volume1,
  VolumeX,
  ExternalLink,
  ListMusic,
  Disc3,
  X,
} from "lucide-react";
import { usePlayer } from "@/lib/player-store";
import { scEmbedUrl } from "@/lib/hsr-data";

/* ---------- SoundCloud Widget API typing ---------- */
declare global {
  interface Window {
    SC?: {
      Widget: {
        Events: { PLAY: string; PAUSE: string; FINISH: string; PLAY_PROGRESS: string };
        (iframe: HTMLIFrameElement | string): SCWidget;
      };
    };
    __scApiLoaded?: boolean;
  }
}

interface SCWidget {
  bind(event: string, cb: (data?: unknown) => void): void;
  play(): void;
  pause(): void;
  seekTo(ms: number): void;
  setVolume(v: number): void;
  getPosition(): number;
  getDuration(): number;
}

function loadScApi() {
  if (window.__scApiLoaded) return;
  window.__scApiLoaded = true;
  const s = document.createElement("script");
  s.src = "https://w.soundcloud.com/player/api.js";
  s.id = "sc-widget-api";
  s.async = true;
  document.head.appendChild(s);
}

function fmt(ms: number): string {
  if (!ms || ms < 0 || !Number.isFinite(ms)) return "0:00";
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, "0")}`;
}

export function PlayerBar() {
  const {
    current,
    playing,
    srcKey,
    open,
    position,
    duration,
    volume,
    toggle,
    next,
    prev,
    setPlaying,
    setPosition,
    setDuration,
    setVolume,
    toggleQueue,
    queueOpen,
    hide,
  } = usePlayer();

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const widgetRef = useRef<SCWidget | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pendingPlayRef = useRef(false);

  /* Load the SoundCloud Widget API up front so it's ready when needed */
  useEffect(() => {
    loadScApi();
  }, []);

  /* NOTE: The player bar is intentionally NOT auto-shown. It only appears
     when the user explicitly plays a song (playSong sets open=true). */

  /* Bind widget events whenever a new track loads */
  const bindWidget = useCallback(() => {
    const iframe = iframeRef.current;
    if (!iframe || !window.SC) return;
    try {
      const widget = window.SC.Widget(iframe);
      widgetRef.current = widget;
      widget.bind(window.SC.Widget.Events.PLAY, () => setPlaying(true));
      widget.bind(window.SC.Widget.Events.PAUSE, () => setPlaying(false));
      widget.bind(window.SC.Widget.Events.FINISH, () => next());
      widget.bind(window.SC.Widget.Events.PLAY_PROGRESS, (data) => {
        const d = data as { currentPosition?: number; relativePosition?: number; loadedProgress?: number };
        if (d?.currentPosition != null) setPosition(d.currentPosition);
        // compute duration from relativePosition if available (relativePosition = pos/duration)
        if (d?.relativePosition && d.relativePosition > 0 && d.currentPosition != null) {
          const computedDur = d.currentPosition / d.relativePosition;
          if (computedDur > 0 && Number.isFinite(computedDur)) {
            setDuration(Math.round(computedDur));
          }
        }
      });
      // fetch duration
      try {
        const dur = widget.getDuration();
        if (dur) setDuration(dur);
      } catch {
        /* not ready */
      }
      // apply current volume
      widget.setVolume(volume);
      if (pendingPlayRef.current) {
        widget.play();
        pendingPlayRef.current = false;
      }
    } catch {
      /* not ready */
    }
  }, [setPlaying, next, setPosition, setDuration, volume]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(bindWidget, 400);
    return () => clearTimeout(t);
  }, [srcKey, open, bindWidget]);

  // Poll position every 500ms as a fallback (PLAY_PROGRESS only fires while playing)
  useEffect(() => {
    if (!open) return;
    pollRef.current = setInterval(() => {
      const w = widgetRef.current;
      if (!w) return;
      try {
        const pos = w.getPosition();
        if (Number.isFinite(pos)) setPosition(pos);
        const dur = w.getDuration();
        if (dur && Number.isFinite(dur)) setDuration(dur);
      } catch {
        /* noop */
      }
    }, 500);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [open, srcKey, setPosition, setDuration]);

  /* Queue autoplay whenever the track changes (srcKey increments).
     We always want to autoplay the new track. */
  useEffect(() => {
    pendingPlayRef.current = true;
  }, [srcKey]);

  /* NOTE: We intentionally do NOT reflect the playing flag onto the widget
     via an effect. That creates a feedback loop: the widget fires transient
     PAUSE events while buffering -> setPlaying(false) -> effect calls pause()
     -> widget stays paused instead of auto-resuming -> flicker (play/pause
     repeatedly). Instead, play/pause commands are issued directly in the
     toggle button handler + bindWidget (for autoplay). Widget events only
     update display state. */

  /* User-initiated play/pause toggle — calls the widget directly */
  const handleToggle = useCallback(() => {
    const w = widgetRef.current;
    if (!w) {
      toggle();
      return;
    }
    try {
      if (playing) w.pause();
      else w.play();
    } catch {
      toggle();
    }
  }, [playing, toggle]);

  /* Minimize/close button — pauses the widget audio, then hides the bar.
     The store's hide() sets open=false + playing=false. */
  const handleHide = useCallback(() => {
    const w = widgetRef.current;
    try {
      w?.pause();
    } catch {
      /* noop */
    }
    hide();
  }, [hide]);

  /* Reflect volume onto the widget */
  useEffect(() => {
    const w = widgetRef.current;
    if (!w) return;
    try {
      w.setVolume(volume);
    } catch {
      /* noop */
    }
  }, [volume]);

  /* Seek when user scrubs the progress bar */
  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const w = widgetRef.current;
    if (!w || !duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const ms = ratio * duration;
    try {
      w.seekTo(ms);
      setPosition(ms);
    } catch {
      /* noop */
    }
  };

  const embedUrl = scEmbedUrl(current, { autoPlay: true });
  const fallback = !current.scSlug;
  const progressPct = duration ? (position / duration) * 100 : 0;

  const VolumeIcon =
    volume === 0 ? VolumeX : volume < 50 ? Volume1 : Volume2;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: "spring", stiffness: 260, damping: 30 }}
          className="fixed inset-x-0 bottom-0 z-50 border-t border-[rgba(201,143,90,0.2)] bg-[#0d0a07]/97 backdrop-blur-2xl"
        >
          {/* hidden SoundCloud widget iframe — the actual audio source */}
          <iframe
            key={srcKey}
            ref={iframeRef}
            src={embedUrl}
            title={`SoundCloud player — ${current.title}`}
            allow="autoplay; encrypted-media"
            scrolling="no"
            frameBorder="0"
            className="pointer-events-none absolute h-0 w-0 opacity-0"
            style={{ border: "none" }}
          />

          <div className="mx-auto flex max-w-[1600px] items-center gap-4 px-4 py-3 sm:px-6">
            {/* LEFT: track info + artwork (Spotify-style) */}
            <div className="flex min-w-0 flex-1 items-center gap-3 sm:w-[28%] sm:flex-none">
              <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-lg overflow-hidden border border-[rgba(201,143,90,0.25)]">
                <div className="absolute inset-0 disc-pattern" />
                <Disc3
                  className={`relative h-6 w-6 text-[#0f0c08] ${
                    playing ? "animate-spin-slow" : ""
                  }`}
                />
              </div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-[#e8b98a]">
                  {current.title}
                </p>
                <p className="truncate text-xs text-[#b8a894]">
                  HSRmusicID
                  {current.collaborator ? ` · ${current.collaborator}` : ""}
                </p>
              </div>
              <a
                href={`https://soundcloud.com/hsrmusicid_official${
                  current.scSlug ? `/${current.scSlug}` : ""
                }`}
                target="_blank"
                rel="noopener noreferrer"
                className="hidden shrink-0 text-[#8a7a66] transition-colors hover:text-[#e8b98a] sm:block"
                aria-label="Buka di SoundCloud"
                title="Buka di SoundCloud"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>

            {/* CENTER: controls + progress scrubber (Spotify-style) */}
            <div className="flex flex-1 flex-col items-center gap-1.5">
              <div className="flex items-center gap-3">
                <button
                  onClick={prev}
                  className="text-[#b8a894] transition-colors hover:text-[#e8b98a]"
                  aria-label="Previous track"
                >
                  <SkipBack className="h-4 w-4 fill-current" />
                </button>
                <button
                  onClick={handleToggle}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-[#f2e9df] text-[#0a0806] transition-transform hover:scale-105"
                  aria-label={playing ? "Pause" : "Play"}
                >
                  {playing ? (
                    <Pause className="h-4 w-4 fill-current" />
                  ) : (
                    <Play className="h-4 w-4 fill-current" />
                  )}
                </button>
                <button
                  onClick={next}
                  className="text-[#b8a894] transition-colors hover:text-[#e8b98a]"
                  aria-label="Next track"
                >
                  <SkipForward className="h-4 w-4 fill-current" />
                </button>
              </div>
              {/* progress scrubber */}
              <div className="flex w-full max-w-xl items-center gap-2">
                <span className="w-9 shrink-0 text-right text-[10px] tabular-nums text-[#8a7a66]">
                  {fmt(position)}
                </span>
                <div
                  onClick={seek}
                  className="group relative h-1 flex-1 cursor-pointer rounded-full bg-[rgba(201,143,90,0.2)]"
                  role="slider"
                  aria-label="Seek"
                  aria-valuenow={Math.round(progressPct)}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-[#a06a3b] to-[#e8b98a] group-hover:from-[#c98f5a] group-hover:to-[#f0cba2]"
                    style={{ width: `${progressPct}%` }}
                  />
                  <div
                    className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#f2e9df] opacity-0 shadow transition-opacity group-hover:opacity-100"
                    style={{ left: `${progressPct}%` }}
                  />
                </div>
                <span className="w-9 shrink-0 text-[10px] tabular-nums text-[#8a7a66]">
                  {fmt(duration)}
                </span>
              </div>
            </div>

            {/* RIGHT: queue + volume (Spotify-style, desktop) */}
            <div className="hidden items-center gap-3 sm:flex sm:w-[28%] sm:justify-end">
              <button
                onClick={toggleQueue}
                className={`rounded p-1.5 transition-colors ${
                  queueOpen
                    ? "text-[#e8b98a]"
                    : "text-[#8a7a66] hover:text-[#e8b98a]"
                }`}
                aria-label="Toggle queue"
                title="Antrian"
              >
                <ListMusic className="h-4 w-4" />
              </button>
              <VolumeIcon className="h-4 w-4 text-[#8a7a66]" />
              <input
                type="range"
                min={0}
                max={100}
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="hsr-vol h-1 w-24 cursor-pointer appearance-none rounded-full bg-[rgba(201,143,90,0.2)] accent-[#c98f5a]"
                aria-label="Volume"
              />
              {/* Minimize/close button — pauses audio and hides the player bar */}
              <button
                onClick={handleHide}
                className="rounded p-1.5 text-[#8a7a66] transition-colors hover:text-[#e8b98a]"
                aria-label="Sembunyikan player"
                title="Sembunyikan player"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          <style>{`
            .hsr-vol::-webkit-slider-thumb {
              -webkit-appearance: none;
              height: 12px; width: 12px;
              border-radius: 999px;
              background: #f2e9df;
              cursor: pointer;
              box-shadow: 0 0 0 0 rgba(201,143,90,0.4);
              transition: box-shadow .2s;
            }
            .hsr-vol:hover::-webkit-slider-thumb { box-shadow: 0 0 0 5px rgba(201,143,90,0.2); }
            .hsr-vol::-moz-range-thumb {
              height: 12px; width: 12px; border: 0;
              border-radius: 999px; background: #f2e9df; cursor: pointer;
            }
          `}</style>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
