"use client";

import { useState } from "react";
import { Home, Music2, Radio, Heart, ListMusic, Disc3, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { HsrLogo } from "./hsr-logo";
import { usePlayer } from "@/lib/player-store";
import { songs, platforms } from "@/lib/hsr-data";
import { platformIconByName } from "./platform-icons";

const navItems = [
  { label: "Beranda", href: "#", icon: Home },
  { label: "Musik", href: "#musik", icon: Music2 },
  { label: "Platform", href: "#platform", icon: Radio },
  { label: "Kontak", href: "#kontak", icon: Heart },
];

export function Sidebar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { current, playSong, sidebarCollapsed, toggleSidebar } = usePlayer();

  // "Up next" = songs after the current one, top 5
  const currentIdx = songs.findIndex((s) => s.id === current.id);
  const upNext = [
    ...songs.slice(currentIdx + 1),
    ...songs.slice(0, currentIdx),
  ].slice(0, 5);

  return (
    <>
      {/* Mobile top bar toggle */}
      <button
        onClick={() => setMobileOpen((v) => !v)}
        className="fixed left-4 top-4 z-[55] flex h-10 w-10 items-center justify-center rounded-full glass-strong text-[#e8b98a] md:hidden"
        aria-label="Toggle menu"
      >
        <ListMusic className="h-5 w-5" />
      </button>

      {/* Backdrop on mobile */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-[55] bg-black/60 backdrop-blur-sm md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed left-0 top-0 z-[56] flex h-screen flex-col border-r border-[rgba(201,143,90,0.15)] bg-[#0d0a07]/95 backdrop-blur-2xl transition-all duration-300 ease-out ${
          sidebarCollapsed ? "w-[72px]" : "w-72"
        } ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0`}
      >
        {/* Logo header + collapse toggle */}
        <div className={`flex items-center ${sidebarCollapsed ? "justify-center px-2" : "justify-between gap-2 px-4"} py-5`}>
          <div className={`flex items-center ${sidebarCollapsed ? "" : "gap-2.5"}`}>
            <HsrLogo className="h-9 w-9 shrink-0 rounded-xl" />
            {!sidebarCollapsed && (
              <div className="leading-tight">
                <p className="font-serif-display text-base font-bold tracking-wide text-[#e8b98a]">
                  HSR<span className="text-[#b8a894] font-normal">music</span>
                </p>
                <p className="text-[10px] uppercase tracking-[0.2em] text-[#a06a3b]">
                  Han Studio
                </p>
              </div>
            )}
          </div>
          {/* Collapse toggle (desktop only) */}
          <button
            onClick={toggleSidebar}
            className="hidden h-8 w-8 shrink-0 items-center justify-center rounded-lg text-[#8a7a66] transition-colors hover:bg-[#221a10] hover:text-[#e8b98a] md:flex"
            aria-label={sidebarCollapsed ? "Lebarkan sidebar" : "Perkecil sidebar"}
            title={sidebarCollapsed ? "Lebarkan" : "Perkecil"}
          >
            {sidebarCollapsed ? (
              <PanelLeftOpen className="h-4 w-4" />
            ) : (
              <PanelLeftClose className="h-4 w-4" />
            )}
          </button>
        </div>

        {/* Main nav */}
        <nav className={`flex flex-col gap-1 ${sidebarCollapsed ? "px-2" : "px-3"}`}>
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              title={sidebarCollapsed ? item.label : undefined}
              className={`group flex items-center rounded-xl text-sm font-medium text-[#b8a894] transition-colors hover:bg-[#221a10] hover:text-[#e8b98a] ${
                sidebarCollapsed
                  ? "h-11 w-11 mx-auto justify-center"
                  : "gap-3 px-3 py-2.5"
              }`}
            >
              <item.icon className="h-4 w-4 shrink-0 text-[#c98f5a]" />
              {!sidebarCollapsed && item.label}
            </a>
          ))}
        </nav>

        {/* Up Next queue (hidden when collapsed) */}
        {!sidebarCollapsed && (
          <div className="mt-6 flex-1 overflow-y-auto px-3">
            <div className="mb-2 flex items-center gap-2 px-3">
              <Disc3 className="h-3.5 w-3.5 text-[#c98f5a]" />
              <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#a06a3b]">
                Up Next
              </p>
            </div>
            <ul className="space-y-0.5">
              {upNext.map((song, i) => (
                <li key={song.id}>
                  <button
                    onClick={() => {
                      playSong(song.id);
                      setMobileOpen(false);
                    }}
                    className="group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left transition-colors hover:bg-[#221a10]"
                  >
                    <span className="w-4 shrink-0 text-right font-serif-display text-xs text-[#a06a3b]">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-medium text-[#d9cdbd] group-hover:text-[#e8b98a]">
                        {song.title}
                      </p>
                      <p className="truncate text-[10px] text-[#8a7a66]">
                        HSRmusicID
                      </p>
                    </div>
                    <Disc3 className="h-3.5 w-3.5 shrink-0 text-[#c98f5a] opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* When collapsed, a spacer to push socials to bottom */}
        {sidebarCollapsed && <div className="flex-1" />}

        {/* Socials */}
        <div className={`border-t border-[rgba(201,143,90,0.15)] py-4 ${sidebarCollapsed ? "px-2" : "px-5"}`}>
          {!sidebarCollapsed && (
            <p className="mb-2 px-1 text-[10px] font-semibold uppercase tracking-[0.25em] text-[#a06a3b]">
              Ikuti
            </p>
          )}
          <div className={`flex ${sidebarCollapsed ? "flex-col items-center gap-2" : "flex-wrap gap-2"}`}>
            {platforms.slice(0, sidebarCollapsed ? 6 : 6).map((p) => (
              <a
                key={p.name}
                href={p.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(201,143,90,0.2)] text-[#b8a894] transition-colors hover:border-[#c98f5a] hover:text-[#e8b98a]"
                aria-label={p.name}
                title={p.name}
              >
                <span className="[&_svg]:h-4 [&_svg]:w-4">
                  {platformIconByName(p.icon)}
                </span>
              </a>
            ))}
          </div>
        </div>
      </aside>
    </>
  );
}
