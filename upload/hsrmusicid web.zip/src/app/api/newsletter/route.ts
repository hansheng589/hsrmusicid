import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { z } from "zod";

const schema = z.object({
  email: z.string().email("Email tidak valid"),
  name: z.string().min(1, "Nama wajib diisi").max(80),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);

    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      return NextResponse.json(
        { ok: false, message: issue?.message ?? "Data tidak valid" },
        { status: 400 }
      );
    }

    const { email, name } = parsed.data;

    // upsert so re-subscribing doesn't throw a unique constraint error
    const subscriber = await db.subscriber.upsert({
      where: { email },
      update: { name },
      create: { email, name },
      select: { id: true },
    });

    return NextResponse.json({
      ok: true,
      message: `Terima kasih ${name}! Kamu telah bergabung dengan newsletter HSRmusicID.`,
      id: subscriber.id,
    });
  } catch (e) {
    console.error("[newsletter] error:", e);
    return NextResponse.json(
      { ok: false, message: "Terjadi kesalahan. Coba lagi nanti." },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const count = await db.subscriber.count();
    return NextResponse.json({ ok: true, count });
  } catch (e) {
    console.error("[newsletter count] error:", e);
    return NextResponse.json({ ok: false, count: 0 }, { status: 500 });
  }
}
