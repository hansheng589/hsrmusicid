import type { MetadataRoute } from "next";

/**
 * Auto-generated sitemap for HSRmusicID.
 *
 * Next.js App Router automatically serves this at `/sitemap.xml` (with the
 * correct `application/xml` content-type). It is regenerated on every request
 * in development, and at build time / on-demand in production.
 *
 * Docs: https://nextjs.org/docs/app/api-reference/file-conventions/metadata/sitemap
 */

// 👉 Ganti dengan domain produksi kamu saat deploy.
const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://hsrmusic.my.id";

// Bagian halaman utama dengan section anchor (scroll-to-section).
// Karena project ini single-page, kita daftarkan section-section penting
// sebagai URL alternatif (#tentang, #musik, dst) supaya search engine
// meng-indeks topik-topik utama.
const sections = [
  { anchor: "", label: "Beranda", priority: 1.0, changeFrequency: "monthly" as const },
  { anchor: "#tentang", label: "Tentang HSRmusicID", priority: 0.9, changeFrequency: "monthly" as const },
  { anchor: "#musik", label: "Diskografi & Lagu", priority: 0.9, changeFrequency: "weekly" as const },
  { anchor: "#platform", label: "Platform Streaming", priority: 0.8, changeFrequency: "monthly" as const },
  { anchor: "#kontak", label: "Kontak", priority: 0.7, changeFrequency: "yearly" as const },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  return sections.map((section) => ({
    url: `${SITE_URL}/${section.anchor}`,
    lastModified: now,
    changeFrequency: section.changeFrequency,
    priority: section.priority,
  }));
}
