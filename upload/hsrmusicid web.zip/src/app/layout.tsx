import type { Metadata } from "next";
import { Cinzel, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cinzel = Cinzel({
  variable: "--font-cinzel",
  subsets: ["latin"],
  weight: ["600", "700"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

// 👉 Ganti dengan domain produksi kamu saat deploy.
const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ?? "https://hsrmusic.my.id";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "HSRmusicID — Official Website | Han Studio Records",
  description:
    "Website resmi HSRmusicID — musisi Indonesian Pop Ballad & Folk-Akustik di bawah Han Studio Records. Dengarkan di Spotify, Apple Music, YouTube Music, dan platform lainnya.",
  keywords: [
    "HSRmusicID",
    "Han Studio Records",
    "Indonesian Pop Ballad",
    "Folk Akustik",
    "musik Indonesia",
    "Sisi Lelaki",
    "Sisi Wanita",
    "Cerita Kita",
  ],
  authors: [{ name: "HSRmusicID" }],
  icons: {
    icon: "/hsr-logo.png",
  },
  alternates: {
    // Memberi tahu crawler lokasi sitemap (komplementer dengan robots.txt)
    types: {},
  },
  openGraph: {
    title: "HSRmusicID — Official Website",
    description:
      "Melodi mendalam, lirik bermakna — Indonesian Pop Ballad & Folk-Akustik dari Han Studio Records.",
    siteName: "HSRmusicID",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "HSRmusicID — Official Website",
    description:
      "Indonesian Pop Ballad & Folk-Akustik dari Han Studio Records.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${cinzel.variable} ${inter.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
