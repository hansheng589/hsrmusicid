import { Hero } from "@/components/hsr/hero";
import { About } from "@/components/hsr/about";
import { Featured } from "@/components/hsr/featured";
import { Marquee } from "@/components/hsr/marquee";
import { Music } from "@/components/hsr/music";
import { Testimonials } from "@/components/hsr/testimonials";
import { Platforms } from "@/components/hsr/platforms";
import { Newsletter } from "@/components/hsr/newsletter";
import { Contact } from "@/components/hsr/contact";
import { Footer } from "@/components/hsr/footer";
import { PlayerBar } from "@/components/hsr/player-bar";
import { BackToTop } from "@/components/hsr/back-to-top";
import { ScrollProgress } from "@/components/hsr/scroll-progress";
import { CursorGlow } from "@/components/hsr/cursor-glow";
import { Sidebar } from "@/components/hsr/sidebar";
import { QueuePanel } from "@/components/hsr/queue-panel";
import { MainContent } from "@/components/hsr/main-content";
import { ShowPlayerButton } from "@/components/hsr/show-player-button";

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-[#0a0806]">
      <ScrollProgress />
      <CursorGlow />
      <Sidebar />
      <QueuePanel />
      {/* Main content — padding adjusts to sidebar collapsed/expanded state */}
      <MainContent>
        <main className="flex-1">
          <Hero />
          <div className="cv-auto">
            <About />
          </div>
          <div className="cv-auto">
            <Featured />
          </div>
          <Marquee />
          <Music />
          <div className="cv-auto">
            <Testimonials />
          </div>
          <Platforms />
          <div className="cv-auto">
            <Newsletter />
          </div>
          <div className="cv-auto">
            <Contact />
          </div>
        </main>
        <Footer />
      </MainContent>
      <PlayerBar />
      <ShowPlayerButton />
      <BackToTop />
    </div>
  );
}
